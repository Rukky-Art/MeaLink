import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/sidebar_nav.dart';

class AvailableFoodScreen extends StatefulWidget {
  const AvailableFoodScreen({super.key});

  @override
  State<AvailableFoodScreen> createState() => _AvailableFoodScreenState();
}

class _AvailableFoodScreenState extends State<AvailableFoodScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  String currentRoute = '/partner/available-food';

  void _navigateTo(String route) {
    if (route == currentRoute) {
      Navigator.pop(context);
      return;
    }
    setState(() => currentRoute = route);
    Navigator.pushReplacementNamed(context, route);
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 700;

    return Scaffold(
      key: _scaffoldKey,
      appBar: isWide
          ? null
          : AppBar(
              title: const Text('Available Food'),
              backgroundColor: Colors.white,
              foregroundColor: Colors.black87,
              elevation: 0,
              leading: IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () => _scaffoldKey.currentState?.openDrawer(),
              ),
            ),
      drawer: isWide
          ? null
          : Drawer(
              child: SidebarNav(
                currentRoute: currentRoute,
                onNavigate: _navigateTo,
                isPartner: true,
              ),
            ),
      body: Row(
        children: [
          if (isWide)
            SidebarNav(
              currentRoute: currentRoute,
              onNavigate: _navigateTo,
              isPartner: true,
            ),
          Expanded(
            child: Container(
              color: const Color(0xFFF8F9FA),
              child: Column(
                children: [
                  _buildHeader(),
                  Expanded(child: _buildEmptyState()),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 60, 24, 20),
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Available Food',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          Row(
            children: [
              const Icon(Icons.location_on,
                  color: AppTheme.primaryGreen, size: 20),
              const SizedBox(width: 6),
              const Text('ADDIS AV',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(20)),
                child: const Text('0 listings'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_bag_outlined,
                size: 90, color: Colors.grey[300]),
            const SizedBox(height: 24),
            const Text('No surplus food in Addis Av right now',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                textAlign: TextAlign.center),
            const SizedBox(height: 12),
            const Text('Check back soon.',
                style: TextStyle(color: Colors.grey, fontSize: 15),
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
