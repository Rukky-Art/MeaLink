import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/sidebar_nav.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  String currentRoute = '/donor/notifications';

  void _navigateTo(String route) {
    if (route == currentRoute) {
      Navigator.pop(context); // Close drawer if open
      return;
    }
    setState(() => currentRoute = route);
    Navigator.pushReplacementNamed(context, route);
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 700;

    return Scaffold(
      key: _scaffoldKey,
      appBar: isWide
          ? null
          : AppBar(
              title: const Text('Notifications'),
              backgroundColor: Colors.white,
              foregroundColor: Colors.black87,
              elevation: 0,
              leading: IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () => _scaffoldKey.currentState?.openDrawer(),
              ),
            ),
      drawer: isWide
          ? null
          : Drawer(
              child: SidebarNav(
                currentRoute: currentRoute,
                onNavigate: _navigateTo,
                isPartner: false, // Important: This is for Donor
              ),
            ),
      body: Row(
        children: [
          if (isWide)
            SidebarNav(
              currentRoute: currentRoute,
              onNavigate: _navigateTo,
              isPartner: false,
            ),
          Expanded(
            child: Container(
              color: const Color(0xFFF8F9FA),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 90,
                      height: 90,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.notifications_outlined,
                        size: 45,
                        color: Colors.grey,
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      'No updates yet',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'When your listings are claimed or picked up,\nyou\'ll see them here.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey, height: 1.5),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
