import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart'; // For kIsWeb
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import '../../theme/app_theme.dart';
import '../../widgets/sidebar_nav.dart';

class CreateListingScreen extends StatefulWidget {
  const CreateListingScreen({super.key});

  @override
  State<CreateListingScreen> createState() => _CreateListingScreenState();
}

class _CreateListingScreenState extends State<CreateListingScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  int _currentStep = 0;

  // Step 1: Details
  final _foodTitleCtrl = TextEditingController();
  String? selectedCategory = 'Cooked Meal';
  final _quantityCtrl = TextEditingController();
  String? selectedUnit = 'Portions';
  final _notesCtrl = TextEditingController();

  // Photo Upload
  PlatformFile? _selectedImage;
  Uint8List? _imageBytes; // For Web + Mobile preview
  bool _isCompressing = false;

  // Step 2: Logistics
  final _cityCtrl = TextEditingController();
  final _fullAddressCtrl = TextEditingController();
  final _availableFromCtrl = TextEditingController();
  final _availableUntilCtrl = TextEditingController();
  final _contactNameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();

  // ==================== PICK & COMPRESS IMAGE ====================
  Future<void> _pickImage() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['png', 'jpg', 'jpeg'],
        allowMultiple: false,
      );

      if (result != null && result.files.isNotEmpty) {
        setState(() => _isCompressing = true);

        final PlatformFile file = result.files.first;

        Uint8List? compressedBytes;

        if (!kIsWeb) {
          // Mobile: Use flutter_image_compress
          final originalFile = File(file.path!);
          final compressedFile = await FlutterImageCompress.compressAndGetFile(
            originalFile.absolute.path,
            '${originalFile.parent.path}/compressed_${DateTime.now().millisecondsSinceEpoch}.jpg',
            quality: 85,
            minWidth: 800,
            minHeight: 800,
          );

          if (compressedFile != null) {
            compressedBytes = await compressedFile.readAsBytes();
          }
        } else {
          // Web: Use original bytes (compression is limited on web)
          compressedBytes = file.bytes;
        }

        if (compressedBytes != null) {
          setState(() {
            _selectedImage = file;
            _imageBytes = compressedBytes;
            _isCompressing = false;
          });
        } else {
          setState(() => _isCompressing = false);
        }
      }
    } catch (e) {
      setState(() => _isCompressing = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error picking image: $e')),
        );
      }
    }
  }

  void _removeImage() {
    setState(() {
      _selectedImage = null;
      _imageBytes = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 700;

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: const Text('Share Food'),
        backgroundColor: Colors.white,
        foregroundColor: AppTheme.textDark,
        elevation: 0,
        leading: isWide
            ? null
            : IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () => _scaffoldKey.currentState?.openDrawer(),
              ),
      ),
      drawer: isWide
          ? null
          : Drawer(
              child: SidebarNav(
                currentRoute: '/donor/create-listing',
                onNavigate: (route) {
                  Navigator.pop(context);
                  Navigator.pushReplacementNamed(context, route);
                },
                isPartner: false,
              ),
            ),
      body: Container(
        color: const Color(0xFFF8F9FA),
        child: Column(
          children: [
            _buildProgressHeader(),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: _buildCurrentStep(),
              ),
            ),
            _buildBottomButtons(),
          ],
        ),
      ),
    );
  }

  // ==================== PROGRESS HEADER ====================
  Widget _buildProgressHeader() {
    /* ... same as before ... */
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      color: Colors.white,
      child: Row(
        children: [
          _stepIndicator('Details', 0),
          const Expanded(
              child:
                  Divider(height: 2, thickness: 2, color: Color(0xFFE0E0E0))),
          _stepIndicator('Logistics', 1),
          const Expanded(
              child:
                  Divider(height: 2, thickness: 2, color: Color(0xFFE0E0E0))),
          _stepIndicator('Review', 2),
        ],
      ),
    );
  }

  Widget _stepIndicator(String label, int step) {
    /* ... same ... */
    final isActive = step == _currentStep;
    final isCompleted = step < _currentStep;

    return Expanded(
      child: Column(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isCompleted || isActive
                  ? AppTheme.primaryGreen
                  : const Color(0xFFE0E0E0),
              border: Border.all(
                  color: isActive ? AppTheme.primaryGreen : Colors.transparent,
                  width: 2),
            ),
            alignment: Alignment.center,
            child: Text(
              (step + 1).toString(),
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color:
                    isCompleted || isActive ? Colors.white : Colors.grey[600],
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
              color: isActive ? AppTheme.primaryGreen : Colors.grey[700],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentStep() {
    if (_currentStep == 0) return _buildDetailsStep();
    if (_currentStep == 1) return _buildLogisticsStep();
    return _buildReviewStep();
  }

  // ==================== STEP 1: DETAILS ====================
  Widget _buildDetailsStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: _pickImage,
          child: Container(
            height: 180,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade300),
            ),
            child: _buildPhotoUploadContent(),
          ),
        ),
        const SizedBox(height: 32),
        const Text('Food Details',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const SizedBox(height: 20),
        const Text('FOOD TITLE *'),
        const SizedBox(height: 8),
        TextField(
          controller: _foodTitleCtrl,
          decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            filled: true,
            fillColor: Colors.white,
          ),
        ),
        const SizedBox(height: 24),
        const Text('CATEGORY'),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: ['Cooked Meal', 'Raw Ingredients', 'Packaged', 'Other']
              .map((cat) => ChoiceChip(
                    label: Text(cat),
                    selected: selectedCategory == cat,
                    onSelected: (selected) => setState(
                        () => selectedCategory = selected ? cat : null),
                    selectedColor: AppTheme.primaryGreen,
                  ))
              .toList(),
        ),
        const SizedBox(height: 24),
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('QUANTITY *'),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _quantityCtrl,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('UNIT'),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    value: selectedUnit,
                    items: ['Portions', 'Kg', 'Liters', 'Boxes']
                        .map((u) => DropdownMenuItem(value: u, child: Text(u)))
                        .toList(),
                    onChanged: (val) => setState(() => selectedUnit = val),
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        const Text('NOTES (optional)'),
        const SizedBox(height: 8),
        TextField(
          controller: _notesCtrl,
          maxLines: 3,
          decoration: InputDecoration(
            hintText: 'Any dietary info, allergens, special instructions...',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            filled: true,
            fillColor: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildPhotoUploadContent() {
    if (_isCompressing) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 12),
            Text('Processing image...', style: TextStyle(color: Colors.grey)),
          ],
        ),
      );
    }

    if (_imageBytes != null) {
      return Stack(
        alignment: Alignment.center,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.memory(
              _imageBytes!,
              fit: BoxFit.cover,
              width: double.infinity,
              height: 180,
            ),
          ),
          Positioned(
            top: 8,
            right: 8,
            child: IconButton(
              onPressed: _removeImage,
              icon: const Icon(Icons.close, color: Colors.white, size: 28),
              style: IconButton.styleFrom(
                backgroundColor: Colors.black.withOpacity(0.7),
              ),
            ),
          ),
        ],
      );
    }

    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.camera_alt_outlined, size: 48, color: Colors.grey),
          SizedBox(height: 8),
          Text('Click to add a photo', style: TextStyle(color: Colors.grey)),
          Text('PNG, JPG up to 10MB',
              style: TextStyle(color: Colors.grey, fontSize: 13)),
        ],
      ),
    );
  }

  // Rest of the methods (Logistics, Review, Bottom Buttons) remain the same
  Widget _buildLogisticsStep() {
    /* ... your existing code ... */
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Pickup Location',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const Text('Where should recipients pick up?',
            style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
                child: TextField(
                    controller: _cityCtrl,
                    decoration: InputDecoration(
                        hintText: 'City *',
                        prefixIcon: const Icon(Icons.location_city),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12)),
                        filled: true,
                        fillColor: Colors.white))),
            const SizedBox(width: 12),
            Expanded(
                child: TextField(
                    controller: _fullAddressCtrl,
                    decoration: InputDecoration(
                        hintText: 'Full Address *',
                        prefixIcon: const Icon(Icons.location_on),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12)),
                        filled: true,
                        fillColor: Colors.white))),
          ],
        ),
        // ... rest of logistics fields
        const SizedBox(height: 32),
        const Text('Pickup Window',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const Text('When is the food available?',
            style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
                child: TextField(
                    controller: _availableFromCtrl,
                    decoration: InputDecoration(
                        hintText: 'mm/dd/yyyy, --:--',
                        suffixIcon: const Icon(Icons.calendar_today),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12)),
                        filled: true,
                        fillColor: Colors.white))),
            const SizedBox(width: 12),
            Expanded(
                child: TextField(
                    controller: _availableUntilCtrl,
                    decoration: InputDecoration(
                        hintText: 'mm/dd/yyyy, --:--',
                        suffixIcon: const Icon(Icons.calendar_today),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12)),
                        filled: true,
                        fillColor: Colors.white))),
          ],
        ),
        const SizedBox(height: 32),
        const Text('Contact (optional)',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const Text('Help recipients reach you',
            style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 16),
        TextField(
            controller: _contactNameCtrl,
            decoration: InputDecoration(
                hintText: 'CONTACT NAME',
                prefixIcon: const Icon(Icons.person),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.white)),
        const SizedBox(height: 12),
        TextField(
            controller: _phoneCtrl,
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(
                hintText: 'Phone Number',
                prefixIcon: const Icon(Icons.phone),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.white)),
      ],
    );
  }

  Widget _buildReviewStep() {
    return const Center(
      child: Text('Review & Submit\n\n(Coming Soon)',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 18, color: Colors.grey)),
    );
  }

  Widget _buildBottomButtons() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey, width: 0.5)),
      ),
      child: Row(
        children: [
          if (_currentStep > 0)
            Expanded(
                child: OutlinedButton(
                    onPressed: () => setState(() => _currentStep--),
                    child: const Text('Back'))),
          if (_currentStep > 0) const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton(
              onPressed: () {
                if (_currentStep < 2) {
                  setState(() => _currentStep++);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text('Listing submitted successfully!')));
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryGreen,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              child: Text(_currentStep == 2 ? 'Submit Listing' : 'Continue',
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _foodTitleCtrl.dispose();
    _quantityCtrl.dispose();
    _notesCtrl.dispose();
    _cityCtrl.dispose();
    _fullAddressCtrl.dispose();
    _availableFromCtrl.dispose();
    _availableUntilCtrl.dispose();
    _contactNameCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }
}
