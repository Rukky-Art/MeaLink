import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/sidebar_nav.dart';

class MyListingsScreen extends StatefulWidget {
  const MyListingsScreen({super.key});

  @override
  State<MyListingsScreen> createState() => _MyListingsScreenState();
}

class _MyListingsScreenState extends State<MyListingsScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 700;

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: const Text('My Listings'),
        backgroundColor: Colors.white,
        foregroundColor: AppTheme.textDark,
        elevation: 0,
        leading: isWide
            ? null
            : IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () => _scaffoldKey.currentState?.openDrawer()),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: ElevatedButton.icon(
              onPressed: () =>
                  Navigator.pushNamed(context, '/donor/create-listing'),
              icon: const Icon(Icons.add, size: 18),
              label: const Text('New Listing'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryGreen,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
              ),
            ),
          ),
        ],
      ),
      drawer: isWide
          ? null
          : Drawer(
              child: SidebarNav(
                currentRoute: '/donor/my-listings',
                onNavigate: (route) {
                  Navigator.pop(context);
                  Navigator.pushReplacementNamed(context, route);
                },
                isPartner: false,
              ),
            ),
      body: Container(
        color: const Color(0xFFF8F9FA),
        child: Column(
          children: [
            _buildFilterTabs(),
            Expanded(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.inbox_outlined,
                        size: 80, color: Colors.grey.shade400),
                    const SizedBox(height: 24),
                    const Text('No listings found.',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w500)),
                    const Text('You haven\'t posted any food yet.',
                        style: TextStyle(color: Colors.grey)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterTabs() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _filterChip('All', true),
            const SizedBox(width: 8),
            _filterChip('Available', false),
            const SizedBox(width: 8),
            _filterChip('Claimed', false),
            const SizedBox(width: 8),
            _filterChip('Picked-up', false),
            const SizedBox(width: 8),
            _filterChip('Distributed', false),
            const SizedBox(width: 8),
            _filterChip('Expired', false),
          ],
        ),
      ),
    );
  }

  Widget _filterChip(String label, bool selected) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: selected ? AppTheme.primaryGreen : Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
            color: selected ? AppTheme.primaryGreen : Colors.grey.shade300),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: selected ? Colors.white : Colors.grey[700],
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
