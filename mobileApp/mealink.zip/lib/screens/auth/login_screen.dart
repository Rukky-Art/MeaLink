import 'package:flutter/material.dart';
import '../../models/user_session.dart';
import '../../theme/app_theme.dart';
import '../../widgets/auth_left_panel.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _obscurePassword = true;
  bool _isLoading = false;

  final _emailFocus = FocusNode();
  final _passwordFocus = FocusNode();

  String? _emailError;
  String? _passwordError;

  String _selectedRole = 'donor';

  @override
  void initState() {
    super.initState();
    _emailController.addListener(_validateEmailLive);
    _setupFocusListeners();
  }

  void _setupFocusListeners() {
    _emailFocus.addListener(() {
      if (!_emailFocus.hasFocus) _validateEmailOnBlur();
    });
    _passwordFocus.addListener(() {
      if (!_passwordFocus.hasFocus) _validatePasswordOnBlur();
    });
  }

  void _validateEmailLive() {
    final email = _emailController.text.trim();
    if (email.isEmpty) {
      setState(() => _emailError = null);
      return;
    }
    setState(() {
      if (!email.contains('@')) {
        _emailError = "Please include '@' in the email address";
      } else if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email)) {
        _emailError = 'Please enter a valid email address';
      } else {
        _emailError = null;
      }
    });
  }

  void _validateEmailOnBlur() {
    final email = _emailController.text.trim();
    setState(() {
      _emailError = email.isEmpty ? 'Email is required' : null;
    });
    if (_emailError == null) _validateEmailLive();
  }

  void _validatePasswordOnBlur() {
    setState(() {
      _passwordError =
          _passwordController.text.isEmpty ? 'Password is required' : null;
    });
  }

  void _validateAndLogin() async {
    _validateEmailOnBlur();
    _validatePasswordOnBlur();
    if (_emailError != null || _passwordError != null) return;

    setState(() => _isLoading = true);
    await Future.delayed(const Duration(milliseconds: 800));

    UserSession.instance.loginAs(
      role: _selectedRole,
      name: _selectedRole == 'donor' ? 'My Business' : 'My Organisation',
      email: _emailController.text.trim(),
    );

    if (!mounted) return;
    setState(() => _isLoading = false);

    if (_selectedRole == 'donor') {
      Navigator.pushReplacementNamed(context, '/donor/dashboard');
    } else {
      Navigator.pushReplacementNamed(context, '/partner/dashboard');
    }
  }

  @override
  void dispose() {
    _emailController.removeListener(_validateEmailLive);
    _emailFocus.dispose();
    _passwordFocus.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  InputDecoration _bubbleDecoration({
    String? hintText,
    String? errorText,
    Widget? suffixIcon,
  }) {
    return InputDecoration(
      hintText: hintText,
      errorText: errorText,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: AppTheme.borderGrey),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: AppTheme.borderGrey),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: AppTheme.primaryGreen, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.red, width: 1.5),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.red, width: 1.5),
      ),
      suffixIcon: suffixIcon,
    );
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 700;

    if (isWide) {
      return Scaffold(
        body: Row(
          children: [
            Expanded(
              child: AuthLeftPanel(
                headline: 'Reduce food waste',
                subtext:
                    'Connect surplus food with people who need it.\nTogether we build a more sustainable community.',
              ),
            ),
            Expanded(child: _buildForm()),
          ],
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppTheme.backgroundCream,
      body: SafeArea(child: _buildForm()),
    );
  }

  Widget _buildForm() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 48),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 400),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Welcome back',
                  style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.textDark)),
              const SizedBox(height: 6),
              const Text('Sign in to your MealLink account',
                  style: TextStyle(fontSize: 14, color: AppTheme.textGrey)),
              const SizedBox(height: 32),

              _label('Email'),
              const SizedBox(height: 6),
              TextField(
                controller: _emailController,
                focusNode: _emailFocus,
                keyboardType: TextInputType.emailAddress,
                decoration: _bubbleDecoration(
                  hintText: 'you@example.com',
                  errorText: _emailError,
                ),
              ),

              const SizedBox(height: 20),
              _label('Password'),
              const SizedBox(height: 6),
              TextField(
                controller: _passwordController,
                focusNode: _passwordFocus,
                obscureText: _obscurePassword,
                decoration: _bubbleDecoration(
                  hintText: '••••••••',
                  errorText: _passwordError,
                  suffixIcon: IconButton(
                    icon: Icon(
                        _obscurePassword
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: AppTheme.textGrey),
                    onPressed: () =>
                        setState(() => _obscurePassword = !_obscurePassword),
                  ),
                ),
              ),

              // Forgot Password
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () =>
                      Navigator.pushNamed(context, '/forgot-password'),
                  child: const Text(
                    'Forgot password?',
                    style: TextStyle(
                      color: AppTheme.primaryGreen,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 8),
              _label('I am signing in as'),
              const SizedBox(height: 8),
              Row(
                children: [
                  _roleChip('donor', 'Food Donor'),
                  const SizedBox(width: 10),
                  _roleChip('partner', 'Distribution Partner'),
                ],
              ),
              const SizedBox(height: 28),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _validateAndLogin,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryGreen,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                      : const Text('Login',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w600)),
                ),
              ),

              const SizedBox(height: 16),
              Center(
                child: GestureDetector(
                  onTap: () => Navigator.pushNamed(context, '/role-selection'),
                  child: RichText(
                    text: const TextSpan(
                      text: "Don't have an account? ",
                      style: TextStyle(color: AppTheme.textGrey, fontSize: 13),
                      children: [
                        TextSpan(
                            text: 'Sign up',
                            style: TextStyle(
                                color: AppTheme.primaryGreen,
                                fontWeight: FontWeight.w600))
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _label(String text) => Text(text,
      style: const TextStyle(
          fontSize: 13, fontWeight: FontWeight.w500, color: AppTheme.textDark));

  Widget _roleChip(String value, String label) {
    final selected = _selectedRole == value;
    return GestureDetector(
      onTap: () => setState(() => _selectedRole = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? AppTheme.primaryGreen : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
              color: selected ? AppTheme.primaryGreen : AppTheme.borderGrey),
        ),
        child: Text(label,
            style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: selected ? Colors.white : AppTheme.textGrey)),
      ),
    );
  }
}
