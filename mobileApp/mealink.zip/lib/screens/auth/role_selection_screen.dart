import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/auth_left_panel.dart';

class RoleSelectionScreen extends StatelessWidget {
  const RoleSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 700;

    if (isWide) {
      return Scaffold(
        body: Row(
          children: [
            Expanded(
              child: AuthLeftPanel(
                headline: 'Join the network',
                subtext: 'Help reduce food waste and support your community.',
              ),
            ),
            Expanded(child: _buildRolePanel(context)),
          ],
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppTheme.backgroundCream,
      body: SafeArea(child: _buildRolePanel(context)),
    );
  }

  Widget _buildRolePanel(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 48),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () => Navigator.pushReplacementNamed(context, '/login'),
                child: Row(
                  children: [
                    const Icon(Icons.arrow_back,
                        size: 20, color: AppTheme.textGrey),
                    const SizedBox(width: 6),
                    const Text(
                      'Back to login',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: AppTheme.textGrey,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),
              const Text(
                'Choose your role',
                style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.textDark),
              ),
              const SizedBox(height: 6),
              const Text(
                'Select how you\'d like to contribute',
                style: TextStyle(fontSize: 14, color: AppTheme.textGrey),
              ),
              const SizedBox(height: 32),
              _RoleCard(
                icon: Icons.restaurant_menu_rounded,
                title: 'Food Donor',
                description: 'Restaurants, bakeries, hotels, event centers',
                onTap: () => Navigator.pushNamed(context, '/register-donor'),
                buttonLabel: 'Continue as Donor',
              ),
              const SizedBox(height: 16),
              _RoleCard(
                icon: Icons.people_alt_rounded,
                title: 'Distribution Partner',
                description: 'NGOs, food banks, community organizations',
                onTap: () => Navigator.pushNamed(context, '/register-partner'),
                buttonLabel: 'Continue as Partner',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final VoidCallback onTap;
  final String buttonLabel;

  const _RoleCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.onTap,
    required this.buttonLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.borderGrey),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppTheme.lightMint,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: AppTheme.primaryGreen, size: 24),
          ),
          const SizedBox(height: 14),
          Text(title,
              style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textDark)),
          const SizedBox(height: 4),
          Text(description,
              style: const TextStyle(fontSize: 13, color: AppTheme.textGrey)),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: onTap,
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.primaryGreen,
                side: const BorderSide(color: AppTheme.primaryGreen),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
              ),
              child: Text(
                buttonLabel,
                style:
                    const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
