import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../../theme/app_theme.dart';
import '../../widgets/auth_left_panel.dart';

class RegisterPartnerScreen extends StatefulWidget {
  const RegisterPartnerScreen({super.key});

  @override
  State<RegisterPartnerScreen> createState() => _RegisterPartnerScreenState();
}

class _RegisterPartnerScreenState extends State<RegisterPartnerScreen> {
  int _currentStep = 1;

  // Step 1 Controllers
  final _contactNameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _confirmPasswordCtrl = TextEditingController();

  // Step 2 Controllers
  final _orgNameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _cityCtrl = TextEditingController();
  final _regNumberCtrl = TextEditingController();

  // File Upload
  PlatformFile? _selectedCertificate;
  String _uploadStatus = 'No file chosen';

  // Dropdown Values
  String? _orgType;
  String? _country;

  bool _obscurePassword = true;
  bool _obscureConfirm = true;
  bool _loading = false;

  // Password Strength
  double _passwordStrength = 0.0;
  String _strengthText = 'Weak';
  Color _strengthColor = Colors.red;

  // Error Messages
  String? _contactNameError;
  String? _emailError;
  String? _passwordError;
  String? _confirmPasswordError;
  String? _orgNameError;
  String? _phoneError;
  String? _passwordRulesError;

  final List<String> _orgTypes = [
    'NGO',
    'Food Bank',
    'Community Organization',
    'Charity',
    'School',
    'Hospital',
    'Religious Organization',
    'Other'
  ];

  final List<String> _countries = [
    'Nigeria',
    'Cameroon',
    'Libya',
    'Kenya',
    'Sudan'
  ];

  // FocusNodes
  final _contactNameFocus = FocusNode();
  final _emailFocus = FocusNode();
  final _passwordFocus = FocusNode();
  final _confirmPasswordFocus = FocusNode();
  final _orgNameFocus = FocusNode();
  final _phoneFocus = FocusNode();

  @override
  void initState() {
    super.initState();
    _passwordCtrl.addListener(_calculatePasswordStrength);
    _emailCtrl.addListener(_validateEmailLive);
    _confirmPasswordCtrl.addListener(_validateConfirmPassword);
    _setupFocusListeners();
  }

  void _setupFocusListeners() {
    _contactNameFocus.addListener(
        () => !_contactNameFocus.hasFocus ? _validateContactName() : null);
    _emailFocus.addListener(
        () => !_emailFocus.hasFocus ? _validateEmailOnBlur() : null);
    _passwordFocus.addListener(
        () => !_passwordFocus.hasFocus ? _validatePassword() : null);
    _confirmPasswordFocus.addListener(() =>
        !_confirmPasswordFocus.hasFocus ? _validateConfirmPassword() : null);
    _orgNameFocus
        .addListener(() => !_orgNameFocus.hasFocus ? _validateOrgName() : null);
    _phoneFocus
        .addListener(() => !_phoneFocus.hasFocus ? _validatePhone() : null);
  }

  // ==================== FILE PICKER ====================
  Future<void> _pickCertificate() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png'],
        allowMultiple: false,
      );

      if (result != null && result.files.isNotEmpty) {
        setState(() {
          _selectedCertificate = result.files.first;
          _uploadStatus = _selectedCertificate!.name;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to pick file: $e')),
        );
      }
    }
  }

  void _removeCertificate() {
    setState(() {
      _selectedCertificate = null;
      _uploadStatus = 'No file chosen';
    });
  }

  // ==================== PASSWORD & VALIDATION ====================
  bool _allPasswordRulesMet() {
    final password = _passwordCtrl.text;
    return password.length >= 8 &&
        password.contains(RegExp(r'[A-Z]')) &&
        password.contains(RegExp(r'[a-z]')) &&
        password.contains(RegExp(r'[0-9]')) &&
        password.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'));
  }

  void _validatePasswordRules() {
    if (_passwordCtrl.text.isEmpty) {
      setState(() => _passwordRulesError = null);
      return;
    }
    setState(() {
      _passwordRulesError = _allPasswordRulesMet()
          ? null
          : 'Password must meet all complexity requirements';
    });
  }

  void _validateEmailLive() {
    final email = _emailCtrl.text.trim();
    if (email.isEmpty) {
      setState(() => _emailError = null);
      return;
    }
    setState(() {
      if (!email.contains('@')) {
        _emailError = "Please include '@' in the email address";
      } else if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email)) {
        _emailError = 'Please enter a valid email address';
      } else {
        _emailError = null;
      }
    });
  }

  void _validateEmailOnBlur() {
    final email = _emailCtrl.text.trim();
    setState(() => _emailError = email.isEmpty ? 'Email is required' : null);
    if (_emailError == null) _validateEmailLive();
  }

  void _calculatePasswordStrength() {
    final password = _passwordCtrl.text;
    int score = 0;
    if (password.length >= 8) score++;
    if (password.contains(RegExp(r'[A-Z]'))) score++;
    if (password.contains(RegExp(r'[a-z]'))) score++;
    if (password.contains(RegExp(r'[0-9]'))) score++;
    if (password.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'))) score++;

    double strength = (score / 5) * 100;
    setState(() {
      _passwordStrength = strength;
      if (strength >= 80) {
        _strengthText = 'Strong';
        _strengthColor = Colors.green;
      } else if (strength >= 50) {
        _strengthText = 'Medium';
        _strengthColor = Colors.orange;
      } else {
        _strengthText = 'Weak';
        _strengthColor = Colors.red;
      }
    });
    _validatePasswordRules();
  }

  void _validateContactName() =>
      setState(() => _contactNameError = _contactNameCtrl.text.trim().isEmpty
          ? 'Please enter contact person name'
          : null);

  void _validatePassword() {
    setState(() => _passwordError =
        _passwordCtrl.text.isEmpty ? 'Please create a password' : null);
    _validatePasswordRules();
  }

  void _validateConfirmPassword() {
    final confirm = _confirmPasswordCtrl.text;
    if (confirm.isEmpty) {
      setState(() => _confirmPasswordError = null);
      return;
    }
    setState(() => _confirmPasswordError =
        (_passwordCtrl.text != confirm) ? 'Passwords do not match' : null);
  }

  void _validateOrgName() =>
      setState(() => _orgNameError = _orgNameCtrl.text.trim().isEmpty
          ? 'Please enter organization name'
          : null);

  void _validatePhone() => setState(() => _phoneError =
      _phoneCtrl.text.trim().isEmpty ? 'Please enter phone number' : null);

  void _nextStep() {
    _validateContactName();
    _validateEmailOnBlur();
    _validatePassword();
    _validateConfirmPassword();
    _validatePasswordRules();

    if ([
      _contactNameError,
      _emailError,
      _passwordError,
      _confirmPasswordError,
      _passwordRulesError
    ].any((e) => e != null)) {
      return;
    }

    setState(() => _currentStep = 2);
  }

  void _handleCreateAccount() async {
    _validateOrgName();
    _validatePhone();

    if (_orgNameError != null || _phoneError != null) return;

    if (_selectedCertificate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please upload your NGO Certificate'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() => _loading = true);

    // Simulated network delay since auth service was removed
    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;
    setState(() => _loading = false);

    Navigator.pushReplacementNamed(context, '/verification');
  }

  @override
  void dispose() {
    _passwordCtrl.removeListener(_calculatePasswordStrength);
    _emailCtrl.removeListener(_validateEmailLive);
    _confirmPasswordCtrl.removeListener(_validateConfirmPassword);

    _contactNameFocus.dispose();
    _emailFocus.dispose();
    _passwordFocus.dispose();
    _confirmPasswordFocus.dispose();
    _orgNameFocus.dispose();
    _phoneFocus.dispose();

    _contactNameCtrl.dispose();
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    _confirmPasswordCtrl.dispose();
    _orgNameCtrl.dispose();
    _phoneCtrl.dispose();
    _cityCtrl.dispose();
    _regNumberCtrl.dispose();

    super.dispose();
  }

  // ==================== UI DECORATION ====================
  InputDecoration _bubbleDecoration({
    String? hintText,
    String? errorText,
    Widget? suffixIcon,
  }) {
    return InputDecoration(
      hintText: hintText,
      errorText: errorText,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: AppTheme.borderGrey),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: AppTheme.borderGrey),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: AppTheme.primaryGreen, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.red, width: 1.5),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.red, width: 1.5),
      ),
      suffixIcon: suffixIcon,
    );
  }

  Widget _field(String label, TextEditingController ctrl,
      {String hint = '',
      TextInputType type = TextInputType.text,
      String? error,
      FocusNode? focusNode}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
        const SizedBox(height: 6),
        TextField(
          controller: ctrl,
          focusNode: focusNode,
          keyboardType: type,
          decoration: _bubbleDecoration(hintText: hint, errorText: error),
        ),
      ],
    );
  }

  // ==================== CERTIFICATE UPLOAD UI ====================
  Widget _buildCertificateUpload() {
    final bool hasFile = _selectedCertificate != null;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Upload NGO Certificate (PDF / Image)',
            style: TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.borderGrey),
          ),
          child: Row(
            children: [
              ElevatedButton(
                onPressed: _pickCertificate,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primaryGreen,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8)),
                ),
                child: const Text('Choose File',
                    style: TextStyle(fontWeight: FontWeight.w600)),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: hasFile
                    ? Row(
                        children: [
                          Expanded(
                            child: Text(
                              _uploadStatus,
                              style: const TextStyle(
                                color: AppTheme.primaryGreen,
                                fontWeight: FontWeight.w500,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          IconButton(
                            onPressed: _removeCertificate,
                            icon: const Icon(Icons.close,
                                color: Colors.red, size: 22),
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                          ),
                        ],
                      )
                    : Text(_uploadStatus,
                        style: TextStyle(color: AppTheme.textGrey)),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ==================== PASSWORD UI ====================
  Widget _buildPasswordStrengthMeter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Password Strength',
                style: TextStyle(fontSize: 12, color: AppTheme.textGrey)),
            Text(_strengthText,
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: _strengthColor)),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: _passwordStrength / 100,
            backgroundColor: Colors.grey[300],
            color: _strengthColor,
            minHeight: 6,
          ),
        ),
      ],
    );
  }

  Widget _passwordRules() {
    final password = _passwordCtrl.text;
    final rules = [
      {'text': 'Minimum 8 characters length', 'met': password.length >= 8},
      {
        'text': 'At least one uppercase character (A-Z)',
        'met': password.contains(RegExp(r'[A-Z]'))
      },
      {
        'text': 'At least one lowercase character (a-z)',
        'met': password.contains(RegExp(r'[a-z]'))
      },
      {
        'text': 'At least one baseline integer (0-9)',
        'met': password.contains(RegExp(r'[0-9]'))
      },
      {
        'text': 'At least one standard symbol structural mark',
        'met': password.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'))
      },
    ];

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.lightMint.withOpacity(0.6),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('COMPLEXITY RULES:',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          ...rules.map((rule) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  children: [
                    Icon(
                      (rule['met'] as bool)
                          ? Icons.check_circle
                          : Icons.circle_outlined,
                      size: 16,
                      color: (rule['met'] as bool)
                          ? Colors.green
                          : AppTheme.textGrey,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        rule['text'] as String,
                        style: TextStyle(
                          fontSize: 12,
                          color: (rule['met'] as bool)
                              ? Colors.green
                              : AppTheme.textGrey,
                        ),
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  // ==================== STEP UI ====================
  Widget _buildStepHeader() {
    return Row(
      children: [
        _stepIndicator(1, 'Credentials', _currentStep >= 1),
        const SizedBox(width: 12),
        Expanded(child: Container(height: 2, color: AppTheme.borderGrey)),
        const SizedBox(width: 12),
        _stepIndicator(2, 'Verification', _currentStep >= 2),
      ],
    );
  }

  Widget _stepIndicator(int step, String label, bool isActive) {
    return Column(
      children: [
        Container(
          width: 28,
          height: 28,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: isActive ? AppTheme.primaryGreen : AppTheme.borderGrey,
          ),
          alignment: Alignment.center,
          child: Text(step.toString(),
              style: TextStyle(
                  color: isActive ? Colors.white : AppTheme.textGrey,
                  fontWeight: FontWeight.bold)),
        ),
        const SizedBox(height: 6),
        Text(label,
            style: TextStyle(
                fontSize: 12,
                color: isActive ? AppTheme.primaryGreen : AppTheme.textGrey)),
      ],
    );
  }

  Widget _buildStep1() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Register as a Partner',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text('Set up your system entry profile identity details.',
            style: TextStyle(color: AppTheme.textGrey)),
        const SizedBox(height: 32),
        _field('Contact Person Name', _contactNameCtrl,
            hint: 'Full Name',
            error: _contactNameError,
            focusNode: _contactNameFocus),
        const SizedBox(height: 20),
        _field('Email Address', _emailCtrl,
            hint: 'you@organization.org',
            type: TextInputType.emailAddress,
            error: _emailError,
            focusNode: _emailFocus),
        const SizedBox(height: 20),
        const Text('Password', style: TextStyle(fontWeight: FontWeight.w500)),
        const SizedBox(height: 6),
        TextField(
          controller: _passwordCtrl,
          focusNode: _passwordFocus,
          obscureText: _obscurePassword,
          decoration: _bubbleDecoration(
            hintText: 'Create a password',
            errorText: _passwordError ?? _passwordRulesError,
            suffixIcon: IconButton(
                icon: Icon(_obscurePassword
                    ? Icons.visibility_off_outlined
                    : Icons.visibility_outlined),
                onPressed: () =>
                    setState(() => _obscurePassword = !_obscurePassword)),
          ),
        ),
        if (_passwordCtrl.text.isNotEmpty) ...[
          const SizedBox(height: 8),
          _buildPasswordStrengthMeter(),
        ],
        const SizedBox(height: 16),
        _passwordRules(),
        const SizedBox(height: 24),
        const Text('Confirm Password',
            style: TextStyle(fontWeight: FontWeight.w500)),
        const SizedBox(height: 6),
        TextField(
          controller: _confirmPasswordCtrl,
          focusNode: _confirmPasswordFocus,
          obscureText: _obscureConfirm,
          decoration: _bubbleDecoration(
            hintText: 'Confirm your password',
            errorText: _confirmPasswordError,
            suffixIcon: IconButton(
                icon: Icon(_obscureConfirm
                    ? Icons.visibility_off_outlined
                    : Icons.visibility_outlined),
                onPressed: () =>
                    setState(() => _obscureConfirm = !_obscureConfirm)),
          ),
        ),
        const SizedBox(height: 40),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _nextStep,
            style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryGreen,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12))),
            child: const Text('Continue to Step 2',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ),
        ),
      ],
    );
  }

  Widget _buildStep2() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Register as a Partner',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text(
            'Provide verification elements for safety compliance checks.',
            style: TextStyle(color: AppTheme.textGrey)),
        const SizedBox(height: 32),
        _field('Organization Name', _orgNameCtrl,
            hint: 'Red Cross Nigeria',
            error: _orgNameError,
            focusNode: _orgNameFocus),
        const SizedBox(height: 16),
        const Text('Organisation Type',
            style: TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          value: _orgType,
          hint: const Text('Select organisation type'),
          decoration: _bubbleDecoration(),
          items: _orgTypes
              .map((type) => DropdownMenuItem(value: type, child: Text(type)))
              .toList(),
          onChanged: (value) => setState(() => _orgType = value),
        ),
        const SizedBox(height: 16),
        const Text('Country',
            style: TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          value: _country,
          hint: const Text('Choose a country'),
          decoration: _bubbleDecoration(),
          items: _countries
              .map((country) =>
                  DropdownMenuItem(value: country, child: Text(country)))
              .toList(),
          onChanged: (value) => setState(() => _country = value),
        ),
        const SizedBox(height: 16),
        _field('City/Area', _cityCtrl, hint: 'Lagos'),
        const SizedBox(height: 16),
        _field('Phone Number', _phoneCtrl,
            hint: '+234 800 000 0000',
            type: TextInputType.phone,
            error: _phoneError,
            focusNode: _phoneFocus),
        const SizedBox(height: 16),
        _field('Government Issued Registration Number', _regNumberCtrl,
            hint: 'e.g. RC / IT / BN Number'),
        const SizedBox(height: 24),
        _buildCertificateUpload(),
        const SizedBox(height: 40),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _loading ? null : _handleCreateAccount,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryGreen,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            child: _loading
                ? const CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2)
                : const Text('Create Account',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ),
        ),
      ],
    );
  }

  Widget _buildForm() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildStepHeader(),
              const SizedBox(height: 32),
              _currentStep == 1 ? _buildStep1() : _buildStep2(),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 700;

    if (isWide) {
      return Scaffold(
        body: Row(
          children: [
            Expanded(
              child: AuthLeftPanel(
                headline: 'Join the network',
                subtext: 'Help reduce food waste and support your community.',
              ),
            ),
            Expanded(child: _buildForm()),
          ],
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppTheme.backgroundCream,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: _currentStep == 1
            ? const BackButton(color: AppTheme.textDark)
            : IconButton(
                icon: const Icon(Icons.arrow_back, color: AppTheme.textDark),
                onPressed: () => setState(() => _currentStep = 1),
              ),
      ),
      body: SafeArea(child: _buildForm()),
    );
  }
}
