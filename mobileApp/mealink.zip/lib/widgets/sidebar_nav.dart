import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class SidebarNav extends StatelessWidget {
  final String currentRoute;
  final Function(String) onNavigate;
  final bool isPartner;

  const SidebarNav({
    super.key,
    required this.currentRoute,
    required this.onNavigate,
    this.isPartner = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Logo
        Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppTheme.primaryGreen,
                  borderRadius: BorderRadius.circular(10),
                ),
                alignment: Alignment.center,
                child: const Text(
                  'M',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 22,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              const Text(
                'MealLink',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.5,
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),

        // Navigation Items
        if (isPartner) ...[
          _navItem(Icons.food_bank_outlined, 'Available Food',
              '/partner/available-food', context),
          _navItem(Icons.history, 'My Claims', '/partner/my-claims', context),
        ] else ...[
          _navItem(
              Icons.grid_view_rounded, 'Overview', '/donor/dashboard', context),
          _navItem(Icons.list_alt_rounded, 'My Listings', '/donor/my-listings',
              context),
          _navItem(Icons.add_circle_outline, 'Create Listing',
              '/donor/create-listing', context),
        ],

        // Notifications - Only show for Donors
        if (!isPartner)
          _navItem(
            Icons.notifications_outlined,
            'Notifications',
            '/donor/notifications',
            context,
          ),

        // Settings (Common for both)
        _navItem(
          Icons.settings_outlined,
          'Settings',
          isPartner ? '/partner/settings' : '/donor/settings',
          context,
        ),

        const Spacer(),
        const Divider(height: 1, color: Colors.grey),
        const SizedBox(height: 20),

        // User Profile
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.lightMint.withOpacity(0.4),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const CircleAvatar(
                  backgroundColor: Color(0xFFE8F5E9),
                  radius: 22,
                  child: Text(
                    'B',
                    style: TextStyle(
                      color: AppTheme.primaryGreen,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Blue',
                        style: TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 16),
                      ),
                      Text(
                        isPartner ? 'PARTNER' : 'DONOR',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 12),

        // Logout
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 20),
          leading: const Icon(Icons.logout, color: Colors.redAccent),
          title: const Text(
            'Logout',
            style: TextStyle(
              color: Colors.redAccent,
              fontWeight: FontWeight.w500,
            ),
          ),
          onTap: () => Navigator.pushReplacementNamed(context, '/login'),
        ),
      ],
    );
  }

  Widget _navItem(
    IconData icon,
    String title,
    String route,
    BuildContext context,
  ) {
    final isSelected = currentRoute == route;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: ListTile(
        leading: Icon(
          icon,
          color: isSelected ? AppTheme.primaryGreen : Colors.grey[700],
          size: 24,
        ),
        title: Text(
          title,
          style: TextStyle(
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
            color: isSelected ? AppTheme.primaryGreen : Colors.grey[800],
            fontSize: 15,
          ),
        ),
        tileColor: isSelected ? AppTheme.lightMint.withOpacity(0.7) : null,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        onTap: () => onNavigate(route),
      ),
    );
  }
}
