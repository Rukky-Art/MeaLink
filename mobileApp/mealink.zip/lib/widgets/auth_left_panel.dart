import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'mealink_logo.dart';

class AuthLeftPanel extends StatelessWidget {
  final String headline;
  final String subtext;

  const AuthLeftPanel({
    super.key,
    required this.headline,
    required this.subtext,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppTheme.lightMint,
      padding: const EdgeInsets.all(40),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const MealLinkLogo(),
          const SizedBox(height: 40),
          // Illustration placeholder (replace with your asset)
          Container(
            width: 200,
            height: 160,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Center(
              child: Icon(
                Icons.people_alt_rounded,
                size: 80,
                color: AppTheme.primaryGreen,
              ),
            ),
          ),
          const SizedBox(height: 32),
          Text(
            headline,
            style: const TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.w800,
              color: AppTheme.textDark,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Text(
            subtext,
            style: const TextStyle(
              fontSize: 14,
              color: AppTheme.textGrey,
              height: 1.5,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
