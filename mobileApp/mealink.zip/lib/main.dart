import 'package:flutter/material.dart';

// Auth Screens
import 'screens/auth/login_screen.dart';
import 'screens/auth/role_selection_screen.dart';
import 'screens/auth/register_donor_screen.dart';
import 'screens/auth/register_partner_screen.dart';
import 'screens/auth/forgot_password_screen.dart';
import 'screens/verification_screen.dart';

// Donor Screens
import 'screens/donor/donor_dashboard.dart';
import 'screens/donor/my_listings_screen.dart';
import 'screens/donor/create_listing_screen.dart';
import 'screens/donor/notifications_screen.dart';
import 'screens/donor/settings_screen.dart';

// Partner Screens
import 'screens/partner/partner_dashboard.dart';
import 'screens/partner/my_claims_screen.dart';
import 'screens/partner/available_food_screen.dart';
import 'screens/partner/settings_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MeaLink',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'SF Pro Display',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1B5E3B),
          primary: const Color(0xFF1B5E3B),
        ),
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => const LoginScreen(),
        '/forgot-password': (context) => const ForgotPasswordScreen(),
        '/role-selection': (context) => const RoleSelectionScreen(),
        '/register-donor': (context) => const RegisterDonorScreen(),
        '/register-partner': (context) => const RegisterPartnerScreen(),
        '/verification': (context) => const VerificationScreen(),
        '/partner/dashboard': (context) => const PartnerDashboard(),
        '/partner/available-food': (context) => const AvailableFoodScreen(),
        '/partner/my-claims': (context) => const MyClaimsScreen(),
        '/partner/settings': (context) => const PartnerSettingsScreen(),
        '/donor/dashboard': (context) => const DonorDashboard(),
        '/donor/my-listings': (context) => const MyListingsScreen(),
        '/donor/create-listing': (context) => const CreateListingScreen(),
        '/donor/notifications': (context) => const NotificationsScreen(),
        '/donor/settings': (context) => const DonorSettingsScreen(),
      },
    );
  }
}
