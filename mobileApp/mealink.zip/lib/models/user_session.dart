/// Simple in-memory session — replace with real auth/storage later.
class UserSession {
  UserSession._();
  static final UserSession instance = UserSession._();

  String? role; // 'donor' | 'partner'
  String? displayName; // business / org name
  String? email;

  bool get isLoggedIn => role != null;
  bool get isDonor => role == 'donor';
  bool get isPartner => role == 'partner';

  void setDonor({required String name, required String email}) {
    role = 'donor';
    displayName = name;
    this.email = email;
  }

  void setPartner({required String name, required String email}) {
    role = 'partner';
    displayName = name;
    this.email = email;
  }

  /// Called when logging in without a fresh registration (mock: default donor).
  /// In a real app this would come from your API response.
  void loginAs(
      {required String role, required String name, required String email}) {
    this.role = role;
    displayName = name;
    this.email = email;
  }

  void logout() {
    role = null;
    displayName = null;
    email = null;
  }
}
